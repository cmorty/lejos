package com.ibm.oti.vm;

import java.io.IOException;

/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 2000, 2002  All Rights Reserved
 * 
 * This class is not distributed with BlueCove binary distrubution: bluecove.jar
 */

public class VM {

	 public static synchronized void loadLibrary(String libName) throws IOException {
		 throw new IOException("Should not be used");
	 }

}
