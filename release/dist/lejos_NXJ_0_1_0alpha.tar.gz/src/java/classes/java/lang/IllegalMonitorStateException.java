package java.lang;

public class IllegalMonitorStateException extends RuntimeException {
}
