
import lejos.nxt.*;
import lejos.robotics.*;

public class TestNavigator {
	
	public static void main (String[] aArg)
	throws Exception
	{
		SimpleNavigator nav = new SimpleNavigator(5.5f,11.2f);
		
		Motor.A.regulateSpeed(true);
		Motor.C.regulateSpeed(true);
		
		Motor.A.setSpeed(300);
		Motor.C.setSpeed(300);
		
		Button.ENTER.waitForPressAndRelease();
		
		nav.rotate(360);
		nav.gotoPoint(100, 0);
		nav.gotoPoint(100, 100);
		nav.gotoPoint(0, 100);
		nav.gotoPoint(0, 0);
		nav.gotoAngle(0);
		
		LCD.clear();
		LCD.drawString("Home", 6, 3);
		LCD.refresh();
		
		Button.ESCAPE.waitForPressAndRelease();
		
		LCD.clear();
		LCD.drawString("Finished", 6, 3);
		LCD.refresh();
	}
}
