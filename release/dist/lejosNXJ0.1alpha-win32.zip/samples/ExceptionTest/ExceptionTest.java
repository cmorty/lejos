import lejos.nxt.*;

public class ExceptionTest {
	
	public static void main (String[] aArg)
	throws Exception
	{
		//int i = 1 / 0;
		
		Port p = Port.PORTS[5];
	}
}
