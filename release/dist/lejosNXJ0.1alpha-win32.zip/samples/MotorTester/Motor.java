import lejos.nxt.Battery;
import lejos.nxt.Button;
import lejos.nxt.LCD;


/**
 * Abstraction for a motor. Three instances of <code>Motor</code>
 * are available: <code>Motor.A</code>, <code>Motor.B</code>
 * and <code>Motor.C</code>. To control each motor use
 * methods <code>forward, backward, reverseDirection, stop</code>
 * and <code>flt</code>. To set each motor's speed, use
 * <code>setSpeed</code>.  
 * <p>
 * Example:<p>
 * <code><pre>
 *   Motor.A.setSpeed(50);
 *   Motor.C.setSpeed(100);
 *   Motor.A.forward();
 *   Motor.C.forward();
 *   Thread.sleep (1000);
 *   Motor.A.stop();
 *   Motor.C.stop();
 * </pre></code>
 */
public class Motor
{
  private char  _id;
  private int _mode = 4;
  private int _speed = 0;
  private int _power = 0;
  private boolean keepGoing = true;// for regulator
  private boolean _regulate = true;
  private byte _direction = 1; // +1 is forward ; used by rotate();
  public Regulator reg = new Regulator();
  private int _limitAngle;
   int _stopAngle;
  private boolean _limit = false;



  /**
   * Motor A.
   */
  public static final Motor A = new Motor ('A');
  /**
   * Motor B.
   */
  public static final Motor B = new Motor ('B');
  /**
   * Motor C.
   */
  public static final Motor C = new Motor ('C');

  private Motor (char aId)
  {
    _id = aId;
    reg.start();
  }
 class Regulator extends Thread
  {
    float smooth = 0.0015f;
  	float basePower = 0;
  	private int time0 = 0;
  	private int angle0 = 0;
  	float power = 0;
  	int elapsed;
  	int angle;
  	float error;
  	float e0 = 0;
  	float kp = 2f;
  	float kd = -1f; 
  	private Stopwatch sw = new Stopwatch();
 	int calcPower(int speed)
 	{   
// 		float pwr = 100 - 6*Battery.getVoltage()+0.055f*speed; // - with turntable
		float pwr = 100 - 7.4f*Battery.getVoltage()+0.065f*speed;
 		if(pwr<0) return 0;
 		if(pwr>100)return 100;
 		else return (int)pwr;
 	}
 	public void startRegulating()
	{
 		_regulate = true;
 		time0 = (int)System.currentTimeMillis();
 		angle0 = getTachoCount();
 		power = calcPower(_speed);
 		basePower = power;
 		setPower((int)power);
// 		LCD.drawInt((int)power,0,3);
// 		LCD.refresh();
 	}
  	public void run()
  	{
	  	while(keepGoing)
	  	{
	  		if(_regulate && isMoving())
	  		{
	  			elapsed = (int)System.currentTimeMillis()-time0;
	  			angle = getTachoCount()-angle0;
	  			error = (elapsed * _speed)/1000f - Math.abs(angle);
	  			power = basePower + 2*error - e0;
	  			e0 = error;
	  			basePower = basePower + smooth*(power-basePower); 
	  			setPower((int)power);
	  		}

  		if(_limit && _direction*(getTachoCount() - _stopAngle)>=0)
  		{
  			 int a0 = getTachoCount();
  			 halt();
  			 boolean turning = true;
  			int a = 0;
  			 while(turning)
  			 {
  			 	sw.reset();
  			 	while(sw.elapsed()<5);
  			 	a = getTachoCount();
  			 	turning = Math.abs(a - a0)>2;
  			 	a0 = a;
  			 }
   			 
  			 LCD.drawInt(a,8,0);
  			 int spd = _speed;
//  			 setSpeed(200);
//  			 if(_direction ==1) forward();
//  			 else backward();
// 
//			while( _direction*(getTachoCount() - _limitAngle)<-3)
			int a1 = getTachoCount();
			LCD.drawInt(a1,12,0);
//			int z =  _direction*(a1 - _limitAngle);
			int z = -(a1 - _limitAngle);
			LCD.drawInt(z,8,2);
			LCD.drawInt(_limitAngle,0,2);
			LCD.drawInt(a1,4,2);
			LCD.drawInt(_direction,12,2);
			if(z>10)LCD.drawInt(z,10,7);
			else LCD.drawInt(z,0,7);
			halt();
			setSpeed(spd);
			LCD.refresh();
  		}
  			 
	  	Thread.yield();
	  	}	
  	}
  }

  private void halt(){stop();}
 public void shutdown(){keepGoing = false;}
  /**
   * Get the ID of the motor. One of 'A', 'B' or 'C'.
   */
  public final char getId()
  {
    return _id;
  }
 
  public void rotateTo(int limitAngle)
	{
		_limitAngle = limitAngle;
		int angle0 = getTachoCount();
		int over = Math.abs(_limitAngle - angle0);
		over = overshoot();
	  	LCD.drawInt(_limitAngle,0,0);


		if(limitAngle >angle0)
		{
			_direction = 1;
			_stopAngle = limitAngle - over;
			LCD.drawInt(_stopAngle,4,0);
			forward();
		}
		else
		{
			 _direction = -1;
			 _stopAngle = _limitAngle + over;
			 LCD.drawInt(_stopAngle,4,0);
			 backward();
		}
		_limit = true;
	}
	private int overshoot()
	{
		int os = (int)( _speed*0.065f);
		os += 10;
//		LCD.drawInt(os,0,3);
		return os;
	}
	public void rotate(int angle)
	{
		rotateTo(getTachoCount()+angle);
	}
	 public void regulate(boolean yes) { _regulate = yes;}

  /**
   * Sets motor power to a <i>value between 0 and 7</i>.
   * @param aSpeed value in the range [0-100].
   */
  public final void setSpeed (int speed)
  {
    _speed = speed;
    setPower((int)reg.calcPower(_speed));
  }
    public final void setPower (int power)
  {
    _power = power;
    controlMotor (_id - 'A', _mode, _power);
  }


  /**
   * Causes motor to rotate forward.
   */
  public final void forward()
  {
    _mode = 1;
    controlMotor (_id - 'A', 1, _power);
    if(_regulate)reg.startRegulating();
    _direction = 1;
  }
  
  /**
   * Return true if motor is forward.
   */
  public final boolean isForward()
  {
    return (_mode == 1);
  }

  /**
   * Causes motor to rotate backwards.
   */
  public final void backward()
  {
    _mode = 2;
    controlMotor (_id - 'A', 2, _power);
    if(_regulate)reg.startRegulating();
    _direction = -1;
  }

  /**
   * Return true if motor is backward.
   */
  public final boolean isBackward()
  {
    return (_mode == 2);
  }

  /**
   * Reverses direction of the motor. It only has
   * effect if the motor is moving.
   */
  public final void reverseDirection()
  {
    if (_mode == 1 || _mode == 2)
    {
      _mode = (3 - _mode);
      _direction *=-1;
      controlMotor (_id - 'A', _mode, _power);
    }
    if(_regulate)reg.startRegulating();
  }
	public final int getPower(){return _power;}


  /**
   * Returns the current motor speed.
   */
  public final int getSpeed()
  {
    return _speed;	  
  }

  /**
   * @return true iff the motor is currently in motion.
   */
  public final boolean isMoving()
  {
    return (_mode == 1 || _mode == 2);	  
  }
  
  /**
   * @return true iff the motor is currently in float mode.
   */
  public final boolean isFloating()
  {
    return _mode == 4;	  
  }
  
  /**
   * Causes motor to stop, pretty much
   * instantaneously. In other words, the
   * motor doesn't just stop; it will resist
   * any further motion.
   */
  public final void stop()
  {
    _mode = 3;
    controlMotor (_id - 'A', 3, 0);

  }
  
  /**
   * Return true if motor is stopped.
   */
  public final boolean isStopped()
  {
    return (_mode == 3);
  }

  /**
   * Causes motor to float. The motor will lose all power,
   * but this is not the same as stopping. Use this
   * method if you don't want your robot to trip in
   * abrupt turns.
   */
  public final void flt()
  {
    _mode = 4;
    controlMotor (_id - 'A', 4, 0);
  }

  /**
   * <i>Low-level API</i> for controlling a motor.
   * This method is not meant to be called directly.
   * If called, other methods such as isRunning() will
   * be unreliable.
   * @deprecated I've decided to remove this method.
   *             If you really need it, check its implementation
   *             in classes/josx/platform/rcx/Motor.java. 
   * @param aMotor The motor id: 'A', 'B' or 'C'.
   * @param aMode 1=forward, 2=backward, 3=stop, 4=float
   * @param aSpeed A value in the range [0-100].
   */
  public static native void controlMotor (int aMotor, int aMode, int aPower);

  public int getTachoCount()
  {
	  return getTachoCountById(_id - 'A');
  }
  
  public static native int getTachoCountById(int aMotor);
}







