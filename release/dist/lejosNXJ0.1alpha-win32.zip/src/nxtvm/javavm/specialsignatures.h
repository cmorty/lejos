/**
 * Machine-generated file. Do not modify.
 */

#ifndef _SPECIALSIGNATURES_H
#define _SPECIALSIGNATURES_H
#define main_4_1Ljava_3lang_3String_2_5V 0
#define run_4_5V 1
#define _6init_7_4_5V 2
#define _6clinit_7_4_5V 3
#define notify_4_5V 4
#define notifyAll_4_5V 5
#define wait_4_5V 6
#define wait_4J_5V 7
#define start_4_5V 8
#define yield_4_5V 9
#define sleep_4J_5V 10
#define currentThread_4_5Ljava_3lang_3Thread_2 11
#define getPriority_4_5I 12
#define setPriority_4I_5V 13
#define interrupt_4_5V 14
#define interrupted_4_5Z 15
#define isInterrupted_4_5Z 16
#define setDaemon_4Z_5V 17
#define isDaemon_4_5Z 18
#define join_4_5V 19
#define join_4J_5V 20
#define currentTimeMillis_4_5J 21
#define exit_4I_5V 22
#define freeMemory_4_5J 23
#define totalMemory_4_5J 24
#define getMessage_4_5Ljava_3lang_3String_2 25
#define readByte_4I_5B 26
#define writeByte_4IB_5V 27
#define setBit_4III_5V 28
#define getDataAddress_4Ljava_3lang_3Object_2_5I 29
#define readSensorValue_4II_5I 30
#define setADTypeById_4II_5V 31
#define setPowerTypeById_4II_5V 32
#define setPoller_4_5V 33
#define setThrottle_4I_5V 34
#define test_4Ljava_3lang_3String_2Z_5V 35
#define testEQ_4Ljava_3lang_3String_2II_5V 36
#define floatToIntBits_4F_5I 37
#define intBitsToFloat_4I_5F 38
#define drawString_4Ljava_3lang_3String_2II_5V 39
#define drawInt_4III_5V 40
#define refresh_4_5V 41
#define clear_4_5V 42
#define setDisplay_4_1I_5V 43
#define getVoltageMilliVolt_4_5I 44
#define readButtons_4_5I 45
#define getTachoCountById_4I_5I 46
#define controlMotor_4III_5V 47
#define resetTachoCountById_4I_5V 48
#endif // _SPECIALSIGNATURES_H
