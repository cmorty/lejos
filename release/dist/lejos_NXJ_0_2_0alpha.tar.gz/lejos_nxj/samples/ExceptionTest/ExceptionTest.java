import lejos.nxt.*;

public class ExceptionTest {
	
	public static void main (String[] aArg)
	throws Exception
	{
		SensorPort p = SensorPort.PORTS[5];
	}
}
