package lejos.nxt;

interface LegacySensorPort extends ADSensorPort {
	
	public void activate();
	
	public void passivate();

}
