package lejos.nxt;

interface BasicMotorPort {
	
	public void controlMotor(int power, int mode);

}
