#ifndef __INTERRUPTS_H__
#  define __INTERRUPTS_H__

int interrupts_get_and_disable(void);
void interrupts_enable(void);

#endif
