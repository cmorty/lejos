#ifndef __LEJOS_NXT_H__
#  define __LEJOS_NXT_H__

#  define MEMORY_SIZE 0x2000
#  define MEMORY_BASE 0x20A00

#endif
