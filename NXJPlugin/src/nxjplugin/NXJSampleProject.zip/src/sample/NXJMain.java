package sample;


import lejos.nxt.*;
// The  library for this project must include  classes.jar from  NXJ_HOME

/**
 *The main class of this project by default.  To upload and run, press F6
 * @author owner
 */
// You can upload and run this class by pressing  F6
public class NXJMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
      // replace with your code
      System.out.println("Press to Start" );
      Button.waitForPress();
    
    }

}

