package java.lang;

/**
 * This is a special Error, which isn't reported by the
 * VM if uncaught. The thread dies quietly.
 */
public class ThreadDeath extends Error
{
}
