package lejos.nxt;

interface TachoMotorPort extends BasicMotorPort, Tachometer {
	
}