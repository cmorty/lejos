package java.lang;

public class OutOfMemoryError extends Error
{
}
