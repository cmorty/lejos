package lejos.nxt;

/**
 * 
 * Abstraction for an RCX motor.
 *
 */
public class RCXMotor extends BasicMotor {
	
	public RCXMotor(BasicMotorPort port)
	{
		_port = port;
	}
}
