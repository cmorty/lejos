/**
 * Machine-generated file. Do not modify.
 */

#ifndef _SPECIALSIGNATURES_H
#define _SPECIALSIGNATURES_H
#define main_4_1Ljava_3lang_3String_2_5V 0
#define run_4_5V 1
#define _6init_7_4_5V 2
#define _6clinit_7_4_5V 3
#define notify_4_5V 4
#define notifyAll_4_5V 5
#define wait_4_5V 6
#define wait_4J_5V 7
#define start_4_5V 8
#define yield_4_5V 9
#define sleep_4J_5V 10
#define currentThread_4_5Ljava_3lang_3Thread_2 11
#define getPriority_4_5I 12
#define setPriority_4I_5V 13
#define interrupt_4_5V 14
#define interrupted_4_5Z 15
#define isInterrupted_4_5Z 16
#define setDaemon_4Z_5V 17
#define isDaemon_4_5Z 18
#define join_4_5V 19
#define join_4J_5V 20
#define currentTimeMillis_4_5J 21
#define exit_4I_5V 22
#define freeMemory_4_5J 23
#define totalMemory_4_5J 24
#define getMessage_4_5Ljava_3lang_3String_2 25
#define readSensorValue_4I_5I 26
#define setADTypeById_4II_5V 27
#define setPowerTypeById_4II_5V 28
#define setPoller_4_5V 29
#define setThrottle_4I_5V 30
#define test_4Ljava_3lang_3String_2Z_5V 31
#define testEQ_4Ljava_3lang_3String_2II_5V 32
#define floatToIntBits_4F_5I 33
#define intBitsToFloat_4I_5F 34
#define drawString_4Ljava_3lang_3String_2II_5V 35
#define drawInt_4III_5V 36
#define drawInt_4IIII_5V 37
#define refresh_4_5V 38
#define clear_4_5V 39
#define setDisplay_4_1I_5V 40
#define getVoltageMilliVolt_4_5I 41
#define readButtons_4_5I 42
#define getTachoCountById_4I_5I 43
#define controlMotorById_4III_5V 44
#define resetTachoCountById_4I_5V 45
#define i2cEnableById_4I_5V 46
#define i2cBusyById_4I_5I 47
#define i2cStartById_4IIII_1BII_5I 48
#define i2cDisableById_4I_5V 49
#define playTone_4II_5V 50
#define btSend_4_1BI_5V 51
#define btReceive_4_1B_5V 52
#define btGetCmdMode_4_5I 53
#define btSetCmdMode_4I_5V 54
#define btStartADConverter_4_5V 55
#endif // _SPECIALSIGNATURES_H
