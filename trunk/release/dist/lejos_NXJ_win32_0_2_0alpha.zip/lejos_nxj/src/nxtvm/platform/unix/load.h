
#ifndef _LOAD_H
#define _LOAD_H

extern void readBinary (char *fileName);
extern void abort_tool (char *msg, char *arg);

#endif // _LOAD_H
