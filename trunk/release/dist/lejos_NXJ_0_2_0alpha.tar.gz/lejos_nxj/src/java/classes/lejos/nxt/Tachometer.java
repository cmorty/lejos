package lejos.nxt;

interface Tachometer {
	
	public int getTachoCount();
	
	public void resetTachoCount();

}
