
public class Stopwatch {
	long millis;
	
	public Stopwatch()
	{
		millis = System.currentTimeMillis();
	}
	
	public void reset()
	{
		millis = System.currentTimeMillis();
	}
	
	public int elapsed()
	{
		return ((int) System.currentTimeMillis() - (int) millis);
	}

}
