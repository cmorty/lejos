import lejos.nxt.Battery;
import lejos.nxt.Button;
import lejos.nxt.LCD;

public class MotorTester 
{

	public static void main(String[] args) 
	{
		Stopwatch sw = new Stopwatch();
//		LCD.drawInt(Battery.getVoltageMilliVolt(),1,7);
//		LCD.refresh();
		Motor m = Motor.A;
		m.setSpeed(700);
		m.rotateTo(360);


		LCD.drawInt(m.getSpeed(),0,4);
		LCD.drawInt(m.getTachoCount(),5,4);
		LCD.refresh();
		while(m.isMoving());
		sw.reset();
		while(sw.elapsed()<500);
		LCD.drawInt(m.getTachoCount(),10,4);
		LCD.refresh();
		m.stop();
		m.shutdown();
	}	
}
