#ifndef _SYSTIME_H
#define _SYSTIME_H

extern FOURBYTES get_sys_time_impl();

#endif // _SYSTIME_H
