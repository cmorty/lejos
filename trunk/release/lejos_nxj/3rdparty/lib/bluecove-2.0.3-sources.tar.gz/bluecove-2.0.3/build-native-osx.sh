#!/bin/sh

# $Id: build-native-osx.sh 1481 2008-01-03 21:08:15Z skarzhevskyy $

BUILD_ROOT=`pwd`

cd src/main/c/intelbth

xcodebuild

cd ${BUILD_ROOT}

cp src/main/resources/libbluecove.jnilib target/classes/
