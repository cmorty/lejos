package sample;


import lejos.nxt.*;

/**
 *
 * @author glassey
 */
public class NewClass
{

   public static void main(String[] args)
   {
      System.out.println(" Hello World");
   }
}
